(function () {
  const KEY_USERS = "hb_users_v1";
  const KEY_SESSION = "hb_session_v1";
  const KEY_RATES = "hb_rates_cache_v1";

  const routes = {
    "/login": renderLogin,
    "/register": renderRegister,
    "/dashboard": renderDashboard,
    "/transfer": renderTransfer,
    "/cotizador": renderCotizador,
    "/movimientos": renderMovimientos,
  };

  function uid() {
    return "u-" + Math.random().toString(36).slice(2, 10);
  }

  function genCBU() {
    let s = "";
    for (let i = 0; i < 22; i++) s += Math.floor(Math.random() * 10);
    return s;
  }

  function readUsers() {
    try {
      return JSON.parse(localStorage.getItem(KEY_USERS)) || [];
    } catch (_) {
      return [];
    }
  }

  function writeUsers(arr) {
    localStorage.setItem(KEY_USERS, JSON.stringify(arr));
  }

  function getMe() {
    const id = localStorage.getItem(KEY_SESSION);
    if (!id) return null;
    return readUsers().find((u) => u.id === id) || null;
  }

  function setSession(id) {
    localStorage.setItem(KEY_SESSION, id);
  }

  function clearSession() {
    localStorage.removeItem(KEY_SESSION);
  }

  function ensureNav() {
    const me = getMe();
    const n = document.getElementById("nav");
    if (!n) return;
    n.innerHTML = me
      ? `<a href="#/dashboard" class="nav">Inicio</a><a href="#/transfer" class="nav">Transferir</a><a href="#/cotizador" class="nav">Cotizador</a><a href="#/movimientos" class="nav">Movimientos</a><a href="#" id="logout" class="nav">Salir</a>`
      : `<a href="#/login" class="nav">Ingresar</a><a href="#/register" class="nav">Crear cuenta</a>`;
    Array.from(n.querySelectorAll("a.nav")).forEach((a) => {
      a.classList.toggle("active", a.getAttribute("href") === location.hash);
    });
    const lo = document.getElementById("logout");
    if (lo) {
      lo.addEventListener("click", (e) => {
        e.preventDefault();
        clearSession();
        location.hash = "#/login";
      });
    }
  }

  async function loadRates() {
    try {
      const cached = localStorage.getItem(KEY_RATES);
      if (cached) return JSON.parse(cached);
      const res = await fetch("./data/rates.json");
      const json = await res.json();
      localStorage.setItem(KEY_RATES, JSON.stringify(json));
      return json;
    } catch (_) {
      return { USD_ARS: { compra: 980, venta: 1020 } };
    }
  }

  function requireAuth() {
    if (!getMe()) {
      location.hash = "#/login";
      return false;
    }
    return true;
  }

  function render(path) {
    ensureNav();
    const root = document.getElementById("app");
    const view = routes[path] || renderLogin;
    root.innerHTML = view();
    ensureNav();
    wire(path);
  }

  function renderLogin() {
    return `
      <div class="center">
        <div class="card auth">
          <h2>Ingresar</h2>
          <div class="row"><label>Email</label><input id="email" type="email" placeholder="tu@mail.com"></div>
          <div class="row"><label>Clave</label><input id="pass" type="password" placeholder="••••••••"></div>
          <div class="row"><button id="login" class="btn">Ingresar</button><a href="#/register" class="small">Crear cuenta</a></div>
        </div>
      </div>`;
  }

  function renderRegister() {
    return `
      <div class="center">
        <div class="card auth">
          <h2>Crear cuenta</h2>
          <div class="row"><label>Nombre</label><input id="name" placeholder="Tu nombre"></div>
          <div class="row"><label>Email</label><input id="email" type="email" placeholder="tu@mail.com"></div>
          <div class="row"><label>Clave</label><input id="pass" type="password" placeholder="Mínimo 6 caracteres"></div>
          <div class="row"><button id="register" class="btn">Crear cuenta</button><a href="#/login" class="small">Ya tengo cuenta</a></div>
        </div>
      </div>`;
  }

  function renderDashboard() {
    if (!requireAuth()) return "";
    const me = getMe();
    return `
      <div class="card">
        <h2>Hola, ${me.name}</h2>
        <div class="small">CBU ${me.cbu}</div>
        <div class="balance">
          <span class="pill">ARS $ ${me.balances.ARS.toFixed(2)}</span>
          <span class="pill">USD ${me.balances.USD.toFixed(2)}</span>
        </div>
      </div>
      <div class="grid cols-2">
        <div class="card">
          <h2>Transferir</h2>
          <div class="row"><label>Moneda</label><select id="t-cur"><option value="ARS">ARS</option><option value="USD">USD</option></select></div>
          <div class="row"><label>Monto</label><input id="t-amt" type="number" min="0" step="0.01" placeholder="0.00"></div>
          <div class="row">
            <label>CBU destino</label>
            <input id="t-cbu" placeholder="22 dígitos">
            <select id="t-recents">
              <option value="">Seleccionar destinatario reciente</option>
              ${(me.recentTransfers || [])
                .slice()
                .reverse()
                .map((r) => `<option value="${r.cbu}">${r.name} • ${r.cbu}</option>`)
                .join("")}
            </select>
          </div>
          <button id="t-send" class="btn">Enviar</button>
          <div class="small">También en la pestaña Transferir</div>
        </div>
        <div class="card">
          <h2>Comprar / Vender Dólar Oficial</h2> 
          <div class="row"><label>Monto ARS (Compra)</label><input id="buy-ars" type="number" min="0" step="0.01" placeholder="0.00"></div>
          <div class="row"><button id="buy" class="btn">Comprar USD</button></div> 
          
          <div class="divider"></div>
          
          <div class="row"><label>Monto USD (Venta)</label><input id="sell-usd" type="number" min="0" step="0.01" placeholder="0.00"></div>
          <div class="row"><button id="sell" class="btn">Vender USD</button></div> 
          
          <div class="row"><span id="rate-info" class="tag"></span></div>
        </div>
      </div>`;
  }

  function renderTransfer() {
    if (!requireAuth()) return "";
    const me = getMe();
    return `
      <div class="card">
        <h2>Transferencia</h2>
        <div class="row"><label>Origen</label><input value="${me.name} • ${me.cbu}" disabled></div>
        <div class="row"><label>Moneda</label><select id="t-cur"><option value="ARS">ARS</option><option value="USD">USD</option></select></div>
        <div class="row"><label>Monto</label><input id="t-amt" type="number" min="0" step="0.01" placeholder="0.00"></div>
        <div class="row">
          <label>CBU destino</label>
          <input id="t-cbu" placeholder="22 dígitos">
          <select id="t-recents">
            <option value="">Seleccionar destinatario reciente</option>
            ${(getMe().recentTransfers || [])
              .slice()
              .reverse()
              .map((r) => `<option value="${r.cbu}">${r.name} • ${r.cbu}</option>`)
              .join("")}
          </select>
        </div>
        <button id="t-send" class="btn">Enviar</button>
      </div>`;
  }

  function renderCotizador() {
    if (!requireAuth()) return "";
    return `
      <div class="card">
        <h2>Cotizador</h2>
        <div class="row"><label>De</label><select id="q-from"><option value="USD">USD</option><option value="ARS">ARS</option></select></div>
        <div class="row"><label>A</label><select id="q-to"><option value="ARS">ARS</option><option value="USD">USD</option></select></div>
        <div class="row"><label>Monto</label><input id="q-amt" type="number" min="0" step="0.01" placeholder="0.00"></div>
        <button id="q-btn" class="btn">Calcular</button>
        <div id="q-out" class="small" style="margin-top:10px"></div>
        <div class="row" style="margin-top:10px"><span id="q-rate" class="tag"></span></div>
      </div>`;
  }

  function renderMovimientos() {
    if (!requireAuth()) return "";
    const me = getMe();
    const labels = {
      TRANSFER_IN: "Transferencia recibida",
      TRANSFER_OUT: "Transferencia enviada",
      BUY_USD_DEBIT: "Compra USD (débito ARS)",
      BUY_USD_CREDIT: "Compra USD (crédito USD)",
      // CAMBIO: Agregar Vender Dólares
      SELL_USD_DEBIT: "Venta USD (débito USD)",
      SELL_USD_CREDIT: "Venta USD (crédito ARS)",
    };
    const labelFor = (m) => {
      // Simplificado, pero la lógica de tu código original es:
      // if (m.tipo === "BUY_USD") {
      //   return m.moneda === "ARS" ? "Compra USD (débito ARS)" : "Compra USD (crédito USD)";
      // }
      // El nuevo sistema de tipos es más claro, pero dejo la estructura anterior por si es relevante.
      return labels[m.tipo] || m.tipo;
    };
    const rows =
      (me.movs || [])
        .slice()
        .reverse()
        .map(
          (m) => `
      <tr>
        <td>${new Date(m.ts).toLocaleString()}</td>
        <td>${labelFor(m)}</td>
        <td>${m.moneda}</td>
        <td>${m.monto > 0 ? "+" : ""}${m.monto.toFixed(2)}</td>
        <td>${m.detalle || "-"}</td>
      </tr>`
        )
        .join("") || `<tr><td colspan="5" class="small">Sin movimientos</td></tr>`;
    return `
      <div class="card">
        <h2>Movimientos</h2>
        <div class="table-wrapper">
          <table class="table">
            <thead><tr><th>Fecha</th><th>Tipo</th><th>Moneda</th><th>Monto</th><th>Detalle</th></tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
      </div>`;
  }

  function wire(path) {
    if (path === "/login") {
      document.getElementById("login").addEventListener("click", () => {
        const email = document.getElementById("email").value.trim().toLowerCase();
        const pass = document.getElementById("pass").value;
        const u = readUsers().find((x) => x.email === email && x.pass === pass);
        if (!u) {
          Swal.fire({ icon: "error", title: "Datos inválidos" });
          return;
        }
        setSession(u.id);
        location.hash = "#/dashboard";
      });
    }

    if (path === "/register") {
      document.getElementById("register").addEventListener("click", () => {
        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim().toLowerCase();
        const pass = document.getElementById("pass").value;
        if (!name || !email || pass.length < 6) {
          Swal.fire({ icon: "error", title: "Completá los datos" });
          return;
        }
        const users = readUsers();
        if (users.some((u) => u.email === email)) {
          Swal.fire({ icon: "error", title: "Email ya registrado" });
          return;
        }
        let cbu = genCBU();
        while (users.some((u) => u.cbu === cbu)) cbu = genCBU();
        const user = {
          id: uid(),
          name,
          email,
          pass,
          cbu,
          balances: { ARS: 100000, USD: 0 },
          movs: [],
          recentTransfers: [],
        };
        users.push(user);
        writeUsers(users);
        setSession(user.id);
        Swal.fire({ icon: "success", title: "Cuenta creada" }).then(
          () => (location.hash = "#/dashboard")
        );
      });
    }

    if (path === "/dashboard" || path === "/transfer") {
      loadRates().then((r) => {
        const tag = document.getElementById("rate-info");
        if (tag && r && r.USD_ARS) {
          tag.textContent =
            "USD/ARS compra " + r.USD_ARS.compra + " • venta " + r.USD_ARS.venta;
        }
      });

      const recentSel = document.getElementById("t-recents");
      if (recentSel) {
        recentSel.addEventListener("change", () => {
          const val = recentSel.value;
          if (val) document.getElementById("t-cbu").value = val;
        });
      }

      const sendBtn = document.getElementById("t-send");
      if (sendBtn) {
        sendBtn.addEventListener("click", () => {
          const cur = document.getElementById("t-cur").value;
          const amt = Number(document.getElementById("t-amt").value);
          const cbu = document.getElementById("t-cbu").value.replace(/\D/g, "");
          const me = getMe();

          if (!amt || amt <= 0) {
            Swal.fire({ icon: "error", title: "Monto inválido" });
            return;
          }
          if (!/^\d{22}$/.test(cbu)) {
            Swal.fire({ icon: "error", title: "CBU inválido" });
            return;
          }
          if (me.balances[cur] < amt) {
            Swal.fire({ icon: "error", title: "Fondos insuficientes" });
            return;
          }

          const users = readUsers();
          const dest = users.find((u) => u.cbu === cbu);
          if (!dest) {
            Swal.fire({ icon: "error", title: "Destino inexistente" });
            return;
          }
          if (dest.id === me.id) {
            Swal.fire({ icon: "error", title: "No podés transferirte a tu propio CBU" });
            return;
          }

          dest.balances[cur] += amt;
          me.balances[cur] -= amt;

          me.movs = me.movs || [];
          dest.movs = dest.movs || [];
          me.movs.push({
            id: uid(),
            ts: Date.now(),
            tipo: "TRANSFER_OUT",
            moneda: cur,
            monto: -amt,
            detalle: "a " + (dest.name || "") + " • " + cbu,
          });
          dest.movs.push({
            id: uid(),
            ts: Date.now(),
            tipo: "TRANSFER_IN",
            moneda: cur,
            monto: amt,
            detalle: "de " + (me.name || "") + " • " + me.cbu,
          });

          me.recentTransfers = me.recentTransfers || [];
          if (!me.recentTransfers.some((r) => r.cbu === cbu)) {
            me.recentTransfers.push({ name: dest.name, cbu });
            if (me.recentTransfers.length > 5) me.recentTransfers.shift();
          }

          const idxMe = users.findIndex((u) => u.id === me.id);
          if (idxMe >= 0) users[idxMe] = me;

          writeUsers(users);
          Toastify({ text: "Transferencia realizada", duration: 2000 }).showToast();
          render("/dashboard");
        });
      }
    }

    if (path === "/dashboard") {
      document.getElementById("buy").addEventListener("click", async () => {
        const me = getMe();
        const r = await loadRates();
        // Compra: el banco te *vende* USD, usa la tasa de *venta*
        const venta = r.USD_ARS.venta; 
        const ars = Number(document.getElementById("buy-ars").value);
        if (!ars || ars <= 0) {
          Swal.fire({ icon: "error", title: "Monto inválido" });
          return;
        }
        if (me.balances.ARS < ars) {
          Swal.fire({ icon: "error", title: "Fondos insuficientes en ARS" });
          return;
        }
        const usd = +(ars / venta).toFixed(2);
        me.balances.ARS -= ars;
        me.balances.USD += usd;

        const users = readUsers();
        const idx = users.findIndex((u) => u.id === me.id);
        if (idx >= 0) {
          me.movs = me.movs || [];
          me.movs.push({
            id: uid(),
            ts: Date.now(),
            tipo: "BUY_USD_DEBIT",
            moneda: "ARS",
            monto: -ars,
            detalle: "compra oficial",
          });
          me.movs.push({
            id: uid(),
            ts: Date.now(),
            tipo: "BUY_USD_CREDIT",
            moneda: "USD",
            monto: usd,
            detalle: "compra oficial",
          });
          users[idx] = me;
          writeUsers(users);
        }

        Swal.fire({
          icon: "success",
          title: "Compra realizada",
          text: "USD acreditados: " + usd,
        });
        render("/dashboard");
      });

      // CAMBIO: Agregar Vender Dólares
      document.getElementById("sell").addEventListener("click", async () => {
        const me = getMe();
        const r = await loadRates();
        // Venta: el banco te *compra* USD, usa la tasa de *compra*
        const compra = r.USD_ARS.compra; 
        const usd = Number(document.getElementById("sell-usd").value);
        
        if (!usd || usd <= 0) {
          Swal.fire({ icon: "error", title: "Monto inválido" });
          return;
        }
        if (me.balances.USD < usd) {
          Swal.fire({ icon: "error", title: "Fondos insuficientes en USD" });
          return;
        }
        
        const ars = +(usd * compra).toFixed(2);
        me.balances.USD -= usd; // Debito USD
        me.balances.ARS += ars; // Credito ARS

        const users = readUsers();
        const idx = users.findIndex((u) => u.id === me.id);
        if (idx >= 0) {
          me.movs = me.movs || [];
          // Movimiento de débito USD
          me.movs.push({
            id: uid(),
            ts: Date.now(),
            tipo: "SELL_USD_DEBIT",
            moneda: "USD",
            monto: -usd,
            detalle: "venta oficial",
          });
          // Movimiento de crédito ARS
          me.movs.push({
            id: uid(),
            ts: Date.now(),
            tipo: "SELL_USD_CREDIT",
            moneda: "ARS",
            monto: ars,
            detalle: "venta oficial",
          });
          users[idx] = me;
          writeUsers(users);
        }

        Swal.fire({
          icon: "success",
          title: "Venta realizada",
          text: "ARS acreditados: $ " + ars.toFixed(2),
        });
        render("/dashboard");
      });
    }

    if (path === "/cotizador") {
      loadRates().then((r) => {
        document.getElementById("q-rate").textContent =
          "USD/ARS compra " + r.USD_ARS.compra + " • venta " + r.USD_ARS.venta;
        document.getElementById("q-btn").addEventListener("click", () => {
          const f = document.getElementById("q-from").value;
          const t = document.getElementById("q-to").value;
          const n = Number(document.getElementById("q-amt").value);
          if (!n || n <= 0) {
            Swal.fire({ icon: "error", title: "Monto inválido" });
            return;
          }
          let out = "";
          if (f === "USD" && t === "ARS") {
            // Recibe ARS por tus USD, usa la tasa de compra del banco
            out = "Recibís ARS $ " + (n * r.USD_ARS.compra).toFixed(2); 
          } else if (f === "ARS" && t === "USD") {
            // Recibe USD por tus ARS, usa la tasa de venta del banco
            out = "Recibís USD " + (n / r.USD_ARS.venta).toFixed(2); 
          } else {
            out = "Elegí monedas distintas";
          }
          document.getElementById("q-out").textContent = out;
        });
      });
    }
  }

  function router() {
    const h = location.hash || "#/login";
    render(h.replace(/^#/, ""));
  }

  window.addEventListener("hashchange", router);
  window.addEventListener("DOMContentLoaded", router);
})();